@echo off
cd /d "%~dp0"
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permissao de Administrador...
    powershell -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
echo Iniciando Ragnalok Overlay...
python overlay-eventos.py --live
if %errorlevel% neq 0 (
    echo.
    echo [Erro] Codigo de saida: %errorlevel%
    pause
)
